module.exports = {
  port: 9545,
  testrpcOptions: '-p 9545 -m "candy maple cake sugar pudding cream honey rich smooth crumble sweet treat"',
  copyNodeModules: true
}
